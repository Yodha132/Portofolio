let titleArrayGlobal = [
    "Economy", "Social"
]

let contentArrayGlobal = [
    "Prices of various commodities, from natural gas to wheat, increase as the Russia-Ukraine war continues due to disruptions in the supply chain. These rising prices affect the ability to afford necessary goods, like food, not only in poorer countries, but everywhere. The World Bank has warned about the risk of regression and stagflation because of the war, in addition to the Covid-19 pandemic.",

    "Many countries have been receiving refugees of the war, providing shelter. There are also threats of food crisis and famine, especially in poorer countries, as the production and distribution of wheat and fertilizers are impeded."
]

let currentContentGlobal = 0
$(document).ready(function () {
    $('#contentTitleGlobal').html(titleArrayGlobal[0]);
    $('#contentTextGlobal').html(contentArrayGlobal[0])
    $('#prev-btn-global').click(function (e) {
        $('#fadeGlobal').fadeOut();
        setTimeout(contentPrev, 400);
        var element = document.getElementById('contentTitleGlobal');
        var headerOffset = 50;
        var elementPosition = element.getBoundingClientRect().top;
        var offsetPosition = elementPosition + window.pageYOffset - headerOffset;

        window.scrollTo({
            top: offsetPosition,
            behavior: "smooth"
        });
        $('#fadeGlobal').fadeIn()
    });

    function contentPrev() {
        if (currentContentGlobal > 0) {
            currentContentGlobal--;
            $('#contentTitleGlobal').html(titleArrayGlobal[currentContentGlobal]);
            $('#contentTextGlobal').html(contentArrayGlobal[currentContentGlobal]);
        } else {
            currentContentGlobal = 1;
            $('#contentTitleGlobal').html(titleArrayGlobal[currentContentGlobal]);
            $('#contentTextGlobal').html(contentArrayGlobal[currentContentGlobal]);
        }
    }

    $('#next-btn-global').click(function (e) {
        $('#fadeGlobal').fadeOut();
        setTimeout(contentNext, 400);
        var element = document.getElementById('contentTitleGlobal');
        var headerOffset = 50;
        var elementPosition = element.getBoundingClientRect().top;
        var offsetPosition = elementPosition + window.pageYOffset - headerOffset;

        window.scrollTo({
            top: offsetPosition,
            behavior: "smooth"
        });
        $('#fadeGlobal').fadeIn()
    });

    function contentNext() {
        if (currentContentGlobal < 1) {
            currentContentGlobal++;
            $('#contentTitleGlobal').html(titleArrayGlobal[currentContentGlobal]);
            $('#contentTextGlobal').html(contentArrayGlobal[currentContentGlobal]);
        } else {
            currentContentGlobal = 0;
            $('#contentTitleGlobal').html(titleArrayGlobal[currentContentGlobal]);
            $('#contentTextGlobal').html(contentArrayGlobal[currentContentGlobal]);
        }
    }

});