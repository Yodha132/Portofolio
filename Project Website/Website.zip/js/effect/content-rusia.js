let titleArrayRusia = [
    "Economy", "Social"
]

let contentArrayRusia = [
    "The effects of the war on the Russian economy is significant. Russia’s oil and gas export, which is a large source of funds for Russia, is decreasing significantly as sanctions are imposed. Central bank assets are frozen and Russian banks are banned from Swift to reduce Russia’s income. Various companies have also suspended or withdrawn trading which leads to a rise in unemployment rate.",

    "Russia’s reputation has worsened. This can have both short-term and long-term negative effects on various aspects and sectors for Russia. People have also become unemployed as companies stopped operating in Russia."
]
let currentContentRusia = 0
$(document).ready(function () {
    $('#contentTitleRusia').html(titleArrayRusia[0]);
    $('#contentTextRusia').html(contentArrayRusia[0])
    $('#prev-btn-rusia').click(function (e) {
        $('#fadeRusia').fadeOut();
        setTimeout(contentPrev, 400);
        var element = document.getElementById('contentTitleRusia');
        var headerOffset = 50;
        var elementPosition = element.getBoundingClientRect().top;
        var offsetPosition = elementPosition + window.pageYOffset - headerOffset;

        window.scrollTo({
            top: offsetPosition,
            behavior: "smooth"
        });
        $('#fadeRusia').fadeIn()
    });

    function contentPrev() {
        if (currentContentRusia > 0) {
            currentContentRusia--;
            $('#contentTitleRusia').html(titleArrayRusia[currentContentRusia]);
            $('#contentTextRusia').html(contentArrayRusia[currentContentRusia]);
        } else {
            currentContentRusia = 1;
            $('#contentTitleRusia').html(titleArrayRusia[currentContentRusia]);
            $('#contentTextRusia').html(contentArrayRusia[currentContentRusia]);
        }
    }

    $('#next-btn-rusia').click(function (e) {
        $('#fadeRusia').fadeOut();
        setTimeout(contentNext, 400);
        var element = document.getElementById('contentTitleRusia');
        var headerOffset = 50;
        var elementPosition = element.getBoundingClientRect().top;
        var offsetPosition = elementPosition + window.pageYOffset - headerOffset;

        window.scrollTo({
            top: offsetPosition,
            behavior: "smooth"
        });
        $('#fadeRusia').fadeIn()
    });

    function contentNext() {
        if (currentContentRusia < 1) {
            currentContentRusia++;
            $('#contentTitleRusia').html(titleArrayRusia[currentContentRusia]);
            $('#contentTextRusia').html(contentArrayRusia[currentContentRusia]);
        } else {
            currentContentRusia = 0;
            $('#contentTitleRusia').html(titleArrayRusia[currentContentRusia]);
            $('#contentTextRusia').html(contentArrayRusia[currentContentRusia]);
        }
    }

});