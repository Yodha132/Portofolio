let titleArray = [
    "Economy", "Social"
]

let contentArray = [
    "The effects of the war on Ukraine’s economy are numerous. Half of Ukraine’s total exports are stopped because of the Black Sea shipping shut down. Farming and harvest operations are disturbed. The World Bank said that the Ukraine economy is estimated to shrink by 45%.",

    "14 million people are displaced from their home, around 7 million have left for other countries, such as Poland and Moldova, while the rest are displaced in Ukraine. However, some people are already returning to Ukraine, to areas that are considered safer now."
]

let contentLength = 2
let currentContent = 0
$(document).ready(function () {
    $('#contentTitle').html(titleArray[0]);
    $('#contentText').html(contentArray[0])
    $('#prev-btn').click(function (e) {
        $('#fade').fadeOut();
        setTimeout(contentPrev, 400);
        var element = document.getElementById('contentTitle');
        var headerOffset = 50;
        var elementPosition = element.getBoundingClientRect().top;
        var offsetPosition = elementPosition + window.pageYOffset - headerOffset;

        window.scrollTo({
            top: offsetPosition,
            behavior: "smooth"
        });
       $('#fade').fadeIn()
    });
    function contentPrev(){
        if (currentContent > 0) {
            currentContent--;
            $('#contentTitle').html(titleArray[currentContent]);
            $('#contentText').html(contentArray[currentContent]);
        } else {
            currentContent = 1;
            $('#contentTitle').html(titleArray[currentContent]);
            $('#contentText').html(contentArray[currentContent]);
        }
    }    

    $('#next-btn').click(function (e) {
        $('#fade').fadeOut();
        setTimeout(contentNext, 400);
        var element = document.getElementById('contentTitle');
        var headerOffset = 50;
        var elementPosition = element.getBoundingClientRect().top;
        var offsetPosition = elementPosition + window.pageYOffset - headerOffset;

        window.scrollTo({
            top: offsetPosition,
            behavior: "smooth"
        });
       $('#fade').fadeIn()
    });

    function contentNext(){
        if (currentContent < 1) {
            currentContent++;
            $('#contentTitle').html(titleArray[currentContent]);
            $('#contentText').html(contentArray[currentContent]);
        } else {
            currentContent = 0;
            $('#contentTitle').html(titleArray[currentContent]);
            $('#contentText').html(contentArray[currentContent]);
        }
    }  

});