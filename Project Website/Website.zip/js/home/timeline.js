let titleArray = [
    "Background", "Russian Annexation of Crimea", "The Beginning of War in Donbas", "Russian Invasion"
]

let contentArray = [
    "The Russo-Ukrainian War is an ongoing war between Russia (together with pro-Russian separatist forces) and Ukraine. It began in February 2014 following the Ukrainian Revolution of Dignity, and initially focused on the status of Crimea and the Donbas, internationally recognised as part of Ukraine. The first eight years of the conflict...",

    "The war between Russia and Ukraine began on 20 February 2014, that Russia began its annexation of Crimea. On 27 February, Russian forces without insignias began their advance into the Crimean Peninsula. They took strategic positions and captured the Crimean Parliament, raising a Russian...",

    "In April, conflict began in eastern Ukraine between Russian-backed separatist forces and Ukrainian government. From 6 April, Militants occupied government buildings in many cities and took control of border crossings to Russia, transport hubs, broadcasting center, and other strategic infrastructure...",

    "By August 2014, the Ukrainian \"Anti-Terrorist Operation\" was able to vastly shrink the territory under the control of the pro-Russian forces, and came close to regaining control of the Russo-Ukrainian border. In response to the deteriorating situation in the Donbas, Russia abandoned its hybrid approach, and began a conventional invasion of the region..."
]
$(document).ready(function () {
    var x = window.matchMedia("(max-width: 768px)")
    $('#tl-title').html(titleArray[0]);
    $('#tl-content').html(contentArray[0]);
    $('#tl-mobile-1').removeClass("d-none");
    $('#tl-arr1').removeClass("d-none");
    $('#tl-img1').removeClass("d-none");
    $('#tl-1').removeClass("d-none");

    $('#tl-1').click(function (e) {
        $('#tl-title').html(titleArray[0]);
        $('#tl-content').html(contentArray[0]);
        $('#tl-img1').removeClass("d-none");
        $('#tl-arr1').removeClass("d-none");
        $('#tl-1').removeClass("d-none");
        $('#tl-mobile-1').removeClass("d-none");
        $('#tl-arr2').addClass("d-none");
        $('#tl-arr3').addClass("d-none");
        $('#tl-arr4').addClass("d-none");
        $('#tl-img2').addClass("d-none");
        $('#tl-img3').addClass("d-none");
        $('#tl-img4').addClass("d-none");
        $('#tl-mobile-2').addClass("d-none");
        $('#tl-mobile-3').addClass("d-none");
        $('#tl-mobile-4').addClass("d-none");

        if (x.matches) {
            var element = document.getElementById('tl-mobile-1');
            var headerOffset = 80;
            var elementPosition = element.getBoundingClientRect().top;
            var offsetPosition = elementPosition + window.pageYOffset - headerOffset;

            window.scrollTo({
                top: offsetPosition,
                behavior: "smooth"
            });
        } else {
            var element = document.getElementById('return-tl');
            var headerOffset = 50;
            var elementPosition = element.getBoundingClientRect().top;
            var offsetPosition = elementPosition + window.pageYOffset - headerOffset;

            window.scrollTo({
                top: offsetPosition,
                behavior: "smooth"
            });
        }
    });

    $('#tl-2').click(function (e) {
        $('#tl-title').html(titleArray[1]);
        $('#tl-content').html(contentArray[1]);
        $('#tl-arr2').removeClass("d-none");
        $('#tl-img2').removeClass("d-none");
        $('#tl-2').removeClass("d-none");
        $('#tl-mobile-2').removeClass("d-none");
        $('#tl-arr1').addClass("d-none");
        $('#tl-arr3').addClass("d-none");
        $('#tl-arr4').addClass("d-none");
        $('#tl-img1').addClass("d-none");
        $('#tl-img3').addClass("d-none");
        $('#tl-img4').addClass("d-none");
        $('#tl-mobile-1').addClass("d-none");
        $('#tl-mobile-3').addClass("d-none");
        $('#tl-mobile-4').addClass("d-none");

        if (x.matches) {
            var element = document.getElementById('tl-mobile-2');
            var headerOffset = 80;
            var elementPosition = element.getBoundingClientRect().top;
            var offsetPosition = elementPosition + window.pageYOffset - headerOffset;

            window.scrollTo({
                top: offsetPosition,
                behavior: "smooth"
            });
        } else {
            var element = document.getElementById('return-tl');
            var headerOffset = 50;
            var elementPosition = element.getBoundingClientRect().top;
            var offsetPosition = elementPosition + window.pageYOffset - headerOffset;

            window.scrollTo({
                top: offsetPosition,
                behavior: "smooth"
            });
        }
    });

    $('#tl-3').click(function (e) {
        $('#tl-title').html(titleArray[2]);
        $('#tl-content').html(contentArray[2]);
        $('#tl-arr3').removeClass("d-none");
        $('#tl-img3').removeClass("d-none");
        $('#tl-mobile-3').removeClass("d-none");
        $('#tl-arr1').addClass("d-none");
        $('#tl-arr2').addClass("d-none");
        $('#tl-arr4').addClass("d-none");
        $('#tl-img1').addClass("d-none");
        $('#tl-img2').addClass("d-none");
        $('#tl-img4').addClass("d-none");
        $('#tl-mobile-1').addClass("d-none");
        $('#tl-mobile-2').addClass("d-none");
        $('#tl-mobile-4').addClass("d-none");

        if (x.matches) {
            var element = document.getElementById('tl-mobile-3');
            var headerOffset = 80;
            var elementPosition = element.getBoundingClientRect().top;
            var offsetPosition = elementPosition + window.pageYOffset - headerOffset;

            window.scrollTo({
                top: offsetPosition,
                behavior: "smooth"
            });
        } else {
            var element = document.getElementById('return-tl');
            var headerOffset = 50;
            var elementPosition = element.getBoundingClientRect().top;
            var offsetPosition = elementPosition + window.pageYOffset - headerOffset;

            window.scrollTo({
                top: offsetPosition,
                behavior: "smooth"
            });
        }
    });

    $('#tl-4').click(function (e) {
        $('#tl-title').html(titleArray[3]);
        $('#tl-content').html(contentArray[3]);
        $('#tl-arr4').removeClass("d-none");
        $('#tl-img4').removeClass("d-none");
        $('#tl-mobile-4').removeClass("d-none");
        $('#tl-arr1').addClass("d-none");
        $('#tl-arr3').addClass("d-none");
        $('#tl-arr2').addClass("d-none");
        $('#tl-img1').addClass("d-none");
        $('#tl-img3').addClass("d-none");
        $('#tl-img2').addClass("d-none");
        $('#tl-mobile-1').addClass("d-none");
        $('#tl-mobile-3').addClass("d-none");
        $('#tl-mobile-2').addClass("d-none");

        if (x.matches) {
            var element = document.getElementById('tl-mobile-4');
            var headerOffset = 80;
            var elementPosition = element.getBoundingClientRect().top;
            var offsetPosition = elementPosition + window.pageYOffset - headerOffset;

            window.scrollTo({
                top: offsetPosition,
                behavior: "smooth"
            });
        } else {
            var element = document.getElementById('return-tl');
            var headerOffset = 50;
            var elementPosition = element.getBoundingClientRect().top;
            var offsetPosition = elementPosition + window.pageYOffset - headerOffset;

            window.scrollTo({
                top: offsetPosition,
                behavior: "smooth"
            });
        }
    });
});