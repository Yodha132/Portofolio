let titleArray = [
    "Etymology", "Geography", "Politics", "Military", "Economy"
]

let contentArray = [
    "<p>The name Russia is derived from Rus, a medieval state populated primarily by the East Slavs. However, the proper name became more prominent in later history, and the country typically was called by its inhabitants \" Rus land \". This state is denoted as Kievan Rus after its capital city by modern historiography. The name Rus' itself comes from the early medieval Rus\' people, a group of Norse merchants and warriors who relocated from across the Baltic Sea and founded a state centered on Novgorod that later became Kievan Rus\'. </p><p> A Medieval Latin version of the name Rus was Ruthenia, which was used as one of several designations for East Slavic and Eastern Orthodox regions, and commonly as a designation for the lands of Rus \'. The current name of the country, Россия (Rossiya), comes from the Byzantine Greek designation of the Rus\',  Ρωσία Rossía– spelled Ρωσία(Rosía pronounced) in Modern Greek.The standard way to refer to the citizens of Russia is \"Russians\" in English.There are two words in Russian which are commonly translated into English as \"Russians\"– one is \"русские\"(russkiye), which most often refers to ethnic Russians and the other is \"россияне\"(rossiyane), which refers to citizens of Russia, regardless of ethnicity.</p>",

    "<p>Russia's vast landmass stretches over the easternmost part of Europe and the northernmost part of Asia. It spans the northernmost edge of Eurasia; and has the world's fourth-longest coastline, of over 37,653 km (23,396 mi). Russia lies between latitudes 41° and 82° N, and longitudes 19° E and 169° W, extending some 9,000 km (5,600 mi) east to west, and 2,500 to 4,000 km (1,600 to 2,500 mi) north to south. Russia, by landmass, is larger than three continents, and has the same surface area as Pluto.</p><p>Russia has nine major mountain ranges, and they are found along the southernmost regions, which share a significant portion of the Caucasus Mountains (containing Mount Elbrus, which at 5,642 m (18,510 ft) is the highest peak in Russia and Europe); the Altai and Sayan Mountains in Siberia; and in the East Siberian Mountains and the Kamchatka Peninsula in the Russian Far East (containing Klyuchevskaya Sopka, which at 4,750 m (15,584 ft) is the highest active volcano in Eurasia). The Ural Mountains, running north to south through the country's west, are rich in mineral resources, and form the traditional boundary between Europe and Asia. The lowest point in Russia and Europe, is situated at the head of the Caspian Sea, where the Caspian Depression reaches some 29 meters (95.1 ft) below sea level.</p>",

    "<p>Russia, by constitution, is an asymmetric federal republic, with a semi-presidential system, wherein the president is the head of state, and the prime minister is the head of government. It is structured as a multi-party representative democracy, with the federal government composed of three branches:<ul><li> Legislative: The bicameral Federal Assembly of Russia, made up of the 450-member State Duma and the 170-member Federation Council, adopts federal law, declares war, approves treaties, has the power of the purse and the power of impeachment of the president.</li><li> Executive: The president is the commander-in-chief of the Armed Forces, and appoints the Government of Russia (Cabinet) and other officers, who administer and enforce federal laws and policies.</li><li> Judiciary: The Constitutional Court, Supreme Court and lower federal courts, whose judges are appointed by the Federation Council on the recommendation of the president, interpret laws and can overturn laws they deem unconstitutional.</li></ul></p> <p> The president is elected by popular vote for a six-year term and may be elected no more than twice. Ministries of the government are composed of the premier and his deputies, ministers, and selected other individuals; all are appointed by the president on the recommendation of the prime minister (whereas the appointment of the latter requires the consent of the State Duma). United Russia is the dominant political party in Russia, and has been described as the big tent and the party of power. Under the administrations of Vladimir Putin, Russia has experienced democratic backsliding, and has become an authoritarian state or dictatorship, with Putin's policies being referred to as Putinism.</p>",

    "<p>The Russian Armed Forces are divided into the Ground Forces, the Navy, and the Aerospace Forces and there are also two independent arms of service: the Strategic Missile Troops and the Airborne Troops. As of 2021, the military has around a million active-duty personnel, which is the world's fifth-largest, and about 2–20 million reserve personnel. It is mandatory for all male citizens aged 18–27 to be drafted for a year of service in the Armed Forces.</p><p> Russia is among the five recognised nuclear-weapons states, with the world's largest stockpile of nuclear weapons; over half of the world's nuclear weapons are owned by Russia. Russia possesses the second-largest fleet of ballistic missile submarines, and is one of the only three countries operating strategic bombers. Russia maintains the world's fourth-highest military expenditure, spending $61.7 billion in 2020. In 2021 it was the world's second-largest arms exporter, and had a large and entirely indigenous defense industry, producing most of its own military equipment. Effectiveness of the Russian military has been questioned, in particular due to widespread corruption.</p>",

    "<p>Russia has a mixed economy, with enormous natural resources, particularly oil and natural gas. It has the world's eleventh-largest economy by nominal GDP and the sixth-largest by PPP. In 2017, the large service sector contributed to 62% of total GDP, the industrial sector 32%, and the small agricultural sector roughly 5%. Russia has a low official unemployment rate of 4.1%. Russia's foreign exchange reserves are the world's fifth-largest. It has a labor force of roughly 70 million, which is the world's sixth-largest. Russia's large automotive industry ranks as the world's tenth-largest by production.</p><p> Russia is the world's twentieth-largest exporter and importer. The oil and gas sector accounted for 45% of Russia's federal budget revenues in January 2022, and up to 60% of its exports in 2019. In 2019, the Natural Resources and Environment Ministry estimated the value of natural resources to be 60% of the country's GDP. Russia has one of the lowest levels of external debt among major economies, although its inequality of household income and wealth is one of the highest among developed countries.</p><p> Following the Russian invasion of Ukraine in 2022, the country has faced international sanctions and corporate boycotts, in a move described as an \"all-out economic and financial war\" to isolate the Russian economy from the global financial system. The European Bank for Reconstruction and Development has estimated the damage done by the sanctions triggered \"the greatest supply shock since at least the early 1970s\", and will retract Russia's economy by 10% in 2022. Some estimates have suggested that sanctions will cost the Russian economy 30 years of development, and reduce the country's living standards for the next 5 years.</p>"
]
let contentLength = 5
let currentContent = 0
$(document).ready(function () {
    $('#contentTitle').html(titleArray[0]);
    $('#contentText').html(contentArray[0])
    $('#prev-btn').click(function (e) {
        $('#rusia-detail').fadeOut();
        setTimeout(contentPrev, 400);
        var element = document.getElementById('contentTitle');
        var headerOffset = 50;
        var elementPosition = element.getBoundingClientRect().top;
        var offsetPosition = elementPosition + window.pageYOffset - headerOffset;

        window.scrollTo({
            top: offsetPosition,
            behavior: "smooth"
        });
       $('#rusia-detail').fadeIn(2000)
    });
    function contentPrev(){
        if (currentContent > 0) {
            currentContent--;
            $('#contentTitle').html(titleArray[currentContent]);
            $('#contentText').html(contentArray[currentContent]);
        } else {
            currentContent = 4;
            $('#contentTitle').html(titleArray[currentContent]);
            $('#contentText').html(contentArray[currentContent]);
        }
    }    

    $('#next-btn').click(function (e) {
        $('#rusia-detail').fadeOut();
        setTimeout(contentNext, 400);
        var element = document.getElementById('contentTitle');
        var headerOffset = 50;
        var elementPosition = element.getBoundingClientRect().top;
        var offsetPosition = elementPosition + window.pageYOffset - headerOffset;

        window.scrollTo({
            top: offsetPosition,
            behavior: "smooth"
        });
       $('#rusia-detail').fadeIn(2000)
    });

    function contentNext(){
        if (currentContent < 4) {
            currentContent++;
            $('#contentTitle').html(titleArray[currentContent]);
            $('#contentText').html(contentArray[currentContent]);
        } else {
            currentContent = 0;
            $('#contentTitle').html(titleArray[currentContent]);
            $('#contentText').html(contentArray[currentContent]);
        }
    }  

});