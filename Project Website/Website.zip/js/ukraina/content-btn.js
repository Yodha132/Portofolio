let titleArray = [
    "Etymology", "Geography", "Politics", "Military", "Economy"
]

let contentArray = [
    "<p>There are different hypotheses as to the etymological origins of the name of Ukraine. The most widespread hypothesis theorizes that it comes from the old Slavic term for \" borderland \", as does the word krajina.</p><p> During most of the 20th century, Ukraine (whether independent or not) was referred to in the English-speaking world prefaced with the definite article, i.e., \"the Ukraine\". This is because the word ukraina means \"borderland\" and so an article would be natural in the English language; this is similar to \"Nederlanden\", which means \"low lands\" and is rendered in English as \"the Netherlands\". However, since Ukraine's declaration of independence in 1991, the use of the definite article in the name has become politicized and is now rarer, and style guides advise against its use. According to US ambassador William Taylor, as of the 2010s using \"the Ukraine\" implies disregard for Ukrainian sovereignty. The official Ukrainian position is that \"the Ukraine\" is incorrect, both grammatically and politically.</p>",

    "<p>Ukraine is the second-largest European country, after Russia. Lying between latitudes 44° and 53° N, and longitudes 22° and 41° E., it is mostly in the East European Plain. Ukraine covers an area of 603,628 square kilometers (233,062 sq mi), with a coastline of 2,782 kilometers (1,729 mi).</p><p> The landscape of Ukraine consists mostly of fertile plains (or steppes) and plateaus, crossed by rivers such as the Dnieper (Dnipro), Seversky Donets, Dniester and the Southern Bug as they flow south into the Black Sea and the smaller Sea of Azov. To the southwest, the delta of the Danube forms the border with Romania. Ukraine's various regions have diverse geographic features ranging from the highlands to the lowlands. The country's only mountains are the Carpathian Mountains in the west, of which the highest is Hoverla at 2,061 meters (6,762 ft), and the Crimean Mountains, in the extreme south along the coast.</p><p> Ukraine also has a number of highland regions such as the Volyn-Podillia Upland (in the west) and the Near-Dnipro Upland (on the right bank of Dnieper). To the east there are the south-western spurs of the Central Russian Upland over which runs the border with the Russian Federation. Near the Sea of Azov can be found the Donets Ridge and the Near Azov Upland. The snow melt from the mountains feeds the rivers and their waterfalls.</p>",

    "<p>The president is elected by popular vote for a five-year term and is the formal head of state. Ukraine's legislative branch includes the 450-seat unicameral parliament, the Verkhovna Rada. The parliament is primarily responsible for the formation of the executive branch and the Cabinet of Ministers, headed by the prime minister. The president retains the authority to nominate the ministers of foreign affairs and of defense for parliamentary approval, as well as the power to appoint the prosecutor general and the head of the Security Service.</p><p> Laws, acts of the parliament and the cabinet, presidential decrees, and acts of the Crimean parliament may be abrogated by the Constitutional Court, should they be found to violate the constitution. Other normative acts are subject to judicial review. The Supreme Court is the main body in the system of courts of general jurisdiction. Local self-government is officially guaranteed. Local councils and city mayors are popularly elected and exercise control over local budgets. The heads of regional and district administrations are appointed by the president in accordance with the proposals of the prime minister.</p>",
    
    "<p>After the dissolution of the Soviet Union, Ukraine inherited a 780,000-man military force on its territory, equipped with the third-largest nuclear weapons arsenal in the world. In 1992, Ukraine signed the Lisbon Protocol in which the country agreed to give up all nuclear weapons to Russia for disposal and to join the Nuclear Non-Proliferation Treaty as a non-nuclear weapon state. By 1996 the country had become free of nuclear weapons.</p><p> Ukraine took consistent steps toward reduction of conventional weapons. It signed the Treaty on Conventional Armed Forces in Europe, which called for reduction of tanks, artillery, and armored vehicles (army forces were reduced to 300,000). The country plans to convert the current conscript-based military into a professional volunteer military. Ukraine's current military consists of 196,600 active personnel and around 900,000 reservists.</p>",
    
    "<p>In 2021 agriculture was the biggest sector of the economy and Ukraine was the world's largest wheat exporter. However, Ukraine remains among the poorest countries in Europe, and corruption remains a widespread issue; the country was rated 122nd out of 180 in the Corruption Perceptions Index for 2021, the second-lowest result in Europe after Russia. In 2021 Ukraine's GDP per capita by purchasing power parity was just over $14,000. Despite supplying emergency financial support, the IMF expected the economy to shrink considerably in 2022 due to Russia's invasion. One 2022 estimate was that post-war reconstruction costs might reach half a trillion dollars.</p><p> In 2021, the average salary in Ukraine reached its highest level at almost ₴14,300 (US$525) per month. About 1% of Ukrainians lived below the national poverty line in 2019. Unemployment in Ukraine was 4.5% in 2019. In 2019 5–15% of the Ukrainian population were categorized as middle class. In 2020 Ukraine's government debt was roughly 50% of its nominal GDP.</p>"
]

let contentLength = 5
let currentContent = 0
$(document).ready(function () {
    $('#contentTitle').html(titleArray[0]);
    $('#contentText').html(contentArray[0])
    $('#prev-btn').click(function (e) {
        $('#rusia-detail').fadeOut();
        setTimeout(contentPrev, 400);
        var element = document.getElementById('contentTitle');
        var headerOffset = 50;
        var elementPosition = element.getBoundingClientRect().top;
        var offsetPosition = elementPosition + window.pageYOffset - headerOffset;

        window.scrollTo({
            top: offsetPosition,
            behavior: "smooth"
        });
       $('#rusia-detail').fadeIn(3000)
    });
    function contentPrev(){
        if (currentContent > 0) {
            currentContent--;
            $('#contentTitle').html(titleArray[currentContent]);
            $('#contentText').html(contentArray[currentContent]);
        } else {
            currentContent = 4;
            $('#contentTitle').html(titleArray[currentContent]);
            $('#contentText').html(contentArray[currentContent]);
        }
    }    

    $('#next-btn').click(function (e) {
        $('#rusia-detail').fadeOut();
        setTimeout(contentNext, 400);
        var element = document.getElementById('contentTitle');
        var headerOffset = 50;
        var elementPosition = element.getBoundingClientRect().top;
        var offsetPosition = elementPosition + window.pageYOffset - headerOffset;

        window.scrollTo({
            top: offsetPosition,
            behavior: "smooth"
        });
       $('#rusia-detail').fadeIn(2000)
    });

    function contentNext(){
        if (currentContent < 4) {
            currentContent++;
            $('#contentTitle').html(titleArray[currentContent]);
            $('#contentText').html(contentArray[currentContent]);
        } else {
            currentContent = 0;
            $('#contentTitle').html(titleArray[currentContent]);
            $('#contentText').html(contentArray[currentContent]);
        }
    }  

});