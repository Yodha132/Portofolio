--1
SELECT ST.CustomerID, CustomerName, CustomerGender, SUM(PO.PhonePrice) AS [Amount of Spending]
FROM SalesTransactionDetail STD
JOIN Phone PO
ON STD.PhoneID = PO.PhoneID
JOIN SalesTransaction ST
ON ST.SalesTransactionDetailID = STD.SalesTransactionDetailID
JOIN Customer CU
ON ST.CustomerID = CU.CustomerID
GROUP BY ST.CustomerID, CustomerName, CustomerGender

--2
SELECT S.StaffID, SUBSTRING
(	
	S.StaffName, 1,
	CHARINDEX(' ', S.StaffName)-1
) AS StaffName,
COUNT(ST.StaffID) AS [Number of Transaction]
FROM SalesTransaction ST
JOIN Staff S
ON S.StaffID = ST.StaffID
GROUP BY S.StaffID, StaffName

--3
SELECT ST.CustomerID, CustomerName, PhoneBrandName,SUM(PhonePrice) AS [Total Spending]
FROM SalesTransaction ST
JOIN SalesTransactionDetail STD
ON ST.SalesTransactionDetailID = STD.SalesTransactionDetailID
JOIN Phone PO
ON STD.PhoneID = PO.PhoneID
JOIN Customer CU
ON ST.CustomerID = CU.CustomerID
JOIN PhoneBrand PB
ON PB.PhoneBrandID = PO.PhoneBrandID
WHERE CU.CustomerName LIKE '% %'
GROUP BY ST.CustomerID, CustomerName, PhoneBrandName
HAVING COUNT(ST.CustomerID)>3
ORDER BY ST.CustomerID;

--4
SELECT ST.StaffID, CONCAT(SUBSTRING(StaffEmail,1,CHARINDEX('@',StaffEmail)-1), '@Ymail.com') AS [StaffEmail], PhoneBrandName,SUM(PhonePrice*PhoneQty) AS [Total Selling]
FROM SalesTransaction ST
JOIN SalesTransactionDetail STD
ON ST.SalesTransactionDetailID = STD.SalesTransactionDetailID
JOIN Staff S
ON S.StaffID = ST.StaffID
JOIN Phone PO
ON STD.PhoneID = PO.PhoneID
JOIN PhoneBrand PB
ON PB.PhoneBrandID = PO.PhoneBrandID
GROUP BY ST.StaffID, StaffEmail,PhoneBrandName
HAVING COUNT(ST.StaffID) > 2
ORDER BY ST.StaffID ASC

--5
SELECT 
	Staff.StaffEmail AS [Staff Email], 
	Staff.StaffGender AS [Staff Gender],
	[Date of Birth] = CONVERT(VARCHAR, Staff.StaffDOB, 106),
	CONCAT('Rp.', Staff.StaffSalary, ',00') AS [Salary]
FROM Staff,
(
	SELECT [Average] = AVG(Staff.StaffSalary)
	FROM Staff
) AS averageSalary
WHERE 
	DATEDIFF(YEAR, Staff.StaffDOB, GETDATE())>=30 
	AND
	StaffSalary > averageSalary.average


--6
SELECT 
	 s.StaffID,
	 s.StaffName, 
	 REPLACE(s.StaffPhoneNum, '+62', '08') AS [StaffPhone],
	 CONCAT('Rp.', SUM(p.PhonePrice), ',00')
FROM 
	Staff s 
	JOIN SalesTransaction st
	ON s.StaffID = st.StaffID
	JOIN SalesTransactionDetail std
	ON st.SalesTransactionDetailID = std.SalesTransactionDetailID
	JOIN Phone p
	ON p.PhoneID = std.PhoneID,
	(
	SELECT [TS] = SUM(p.PhonePrice)
	FROM SalesTransaction st
	JOIN SalesTransactionDetail std
	ON st.SalesTransactionDetailID = std.SalesTransactionDetailID
	JOIN Phone p
	ON p.PhoneID = std.PhoneID
	JOIN Staff s
	ON s.StaffID = st.StaffID
	WHERE s.StaffGender = 'Male'
	) AS total
WHERE 
	total.TS > 10000000 
	AND 
	total.TS < 100000000
GROUP BY s.StaffID, s.StaffName, s.StaffPhoneNum


--7 
SELECT
[Staff No] = 'Staff No' + SUBSTRING(s.StaffID,4,5),
s.StaffName,
[Email] = SUBSTRING(s.StaffEmail,1,CHARINDEX('@',s.StaffEmail,1)-1) + '@gmail.com',
[Date Of Birth] = convert(varchar,s.StaffDOB,103),

[Customer Count] = TransactionCustomer.CountCustomer
FROM Staff s JOIN SalesTransaction t
ON s.StaffID = t.StaffID
JOIN (
	SELECT SalesTransaction.CustomerID,
	COUNT(SalesTransaction.CustomerID)
	AS "CountCustomer" 
	FROM SalesTransaction 
	GROUP BY SalesTransaction.CustomerID
) AS TransactionCustomer
ON t.CustomerID = TransactionCustomer.CustomerID
WHERE TransactionCustomer.CountCustomer = (
	SELECT MAX(CountCustomer) FROM(
		SELECT SalesTransaction.CustomerID,
		COUNT(SalesTransaction.CustomerID)
		AS "CountCustomer" 
		FROM SalesTransaction 
		GROUP BY SalesTransaction.CustomerID) AS TransactionCustomer)
--GROUP BY s.StaffID,s.StaffName,s.StaffEmail,s.StaffDOB
-- ini yg aku count bener gak ya?
-- staff ->itungnya customer


--8
SELECT PB.PhoneBrandID, PB.PhoneBrandName, CS.CustomerID, CS.CustomerName, [Customer Email] = REPLACE(CustomerEmail, SUBSTRING(CustomerEmail, CHARINDEX('@',CustomerEmail)+1, LEN(CustomerEmail) - CHARINDEX('@',CustomerEmail)), 'Gmail.com'), [Qty] = SUM(PhoneQty)
FROM PhoneBrand PB
JOIN Phone PH ON PB.PhoneBrandID=PH.PhoneBrandID
JOIN SalesTransactionDetail STD ON PH.PhoneID=STD.PhoneID
JOIN SalesTransaction ST ON STD.SalesTransactionDetailID=ST.SalesTransactionDetailID
JOIN Customer CS ON ST.CustomerID=CS.CustomerID
JOIN (
    SELECT CustomerID
    from Customer
    where CAST(RIGHT(CustomerID,3) AS int) % 2 = 0 
) as sub on sub.CustomerID = CS.CustomerID
WHERE CustomerEmail LIKE '%@bluejack.com' 
GROUP BY PB.PhoneBrandID, PB.PhoneBrandName, CS.CustomerID, CS.CustomerName, REPLACE(CustomerEmail, SUBSTRING(CustomerEmail, CHARINDEX('@',CustomerEmail)+1, LEN(CustomerEmail) - CHARINDEX('@',CustomerEmail)), 'Gmail.com')
ORDER BY PhoneBrandID ASC


--9
CREATE VIEW Vendor_Brand_Transaction_View
AS
SELECT [VendorID] = CONCAT('Vendor', RIGHT(VE.VendorID, 3)), VendorName, [VendorPhoneNum] = REPLACE(VendorPhoneNum, '+62', '08'), PhoneBrandName, [Transaction Count] = COUNT(PH.PhoneBrandID), [Total Transaction] = SUM(PhonePrice*PhoneQty)
FROM VENDOR VE
JOIN PurchaseTransaction PT ON VE.VendorID=PT.VendorID
JOIN Staff STA ON PT.StaffID=STA.StaffID
JOIN SalesTransaction ST ON STA.StaffID=ST.StaffID
JOIN SalesTransactionDetail STD ON ST.SalesTransactionDetailID=STD.SalesTransactionDetailID
JOIN PHONE PH ON STD.PhoneID=PH.PhoneID
JOIN PhoneBrand PB ON PH.PhoneBrandID=PB.PhoneBrandID
GROUP BY CONCAT('Vendor', RIGHT(VE.VendorID, 3)), VendorName, REPLACE(VendorPhoneNum, '+62', '08'), PhoneBrandName


--10
CREATE VIEW Staff_Selling_View
AS
SELECT STA.StaffID, StaffName, [Sold Phone] = CONCAT(CONVERT(VARCHAR,SUM(STD.PhoneQty)), 'pc(s)'), [Total Transaction] = CONCAT('Rp.', CONVERT(VARCHAR,SUM(PhonePrice*PhoneQty)), ',00.'), [Count Brand] = COUNT(PH.PhoneBrandID)
FROM Staff STA
JOIN SalesTransaction ST ON STA.StaffID=ST.StaffID
JOIN SalesTransactionDetail STD ON ST.SalesTransactionDetailID=STD.SalesTransactionDetailID
JOIN PHONE PH ON STD.PhoneID=PH.PhoneID
JOIN PhoneBrand PB ON PH.PhoneBrandID=PB.PhoneBrandID
WHERE StaffEmail LIKE '%@bluejack.com' 
GROUP BY STA.StaffID, StaffName