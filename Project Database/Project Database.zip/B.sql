CREATE DATABASE FlexPhone
USE FlexPhone
DROP DATABASE FlexPhone
CREATE TABLE Staff
(
	StaffID CHAR(5) PRIMARY KEY CHECK(StaffId LIKE 'ST[0-9][0-9][0-9]') NOT NULL,
	StaffName VARCHAR(20) NOT NULL,
	StaffEmail VARCHAR(30) CHECK(StaffEmail LIKE '%@bluejack.com' OR StaffEmail LIKE '%@sunib.edu') NOT NULL,
	StaffDOB DATE CHECK(YEAR(StaffDOB)>=1960) NOT NULL,
	StaffGender VARCHAR(6) CHECK(StaffGender LIKE 'Male' OR StaffGender LIKE 'Female') NOT NULL,
	StaffPhoneNum VARCHAR(15) NOT NULL,
	StaffAddress VARCHAR(255) NOT NULL,
	StaffSalary INT NOT NULL,
)

CREATE TABLE Vendor
(
	VendorID CHAR(5) PRIMARY KEY CHECK(VendorID LIKE 'VE[0-9][0-9][0-9]') NOT NULL,
	VendorName VARCHAR(20) NOT NULL,
	VendorEmail VARCHAR(30) CHECK(VendorEmail LIKE '%@bluejack.com' OR VendorEmail LIKE '%@sunib.edu') NOT NULL,
	VendorPhoneNum VARCHAR(15) NOT NULL,
	VendorAddress VARCHAR(255) NOT NULL
)

CREATE TABLE PhoneBrand
(
	PhoneBrandID CHAR(5) PRIMARY KEY CHECK(PhoneBrandID LIKE 'PB[0-9][0-9][0-9]') NOT NULL,
	PhoneBrandName VARCHAR(10) NOT NULL
)

CREATE TABLE Phone
(
	PhoneID CHAR(5) PRIMARY KEY CHECK(PhoneID LIKE 'PO[0-9][0-9][0-9]') NOT NULL,
	PhoneBrandID CHAR(5) FOREIGN KEY REFERENCES PhoneBrand(PhoneBrandID) ON UPDATE CASCADE ON DELETE CASCADE NOT NULL,
	PhoneName VARCHAR(20) NOT NULL,
	PhonePrice INT CHECK(PhonePrice>100000 AND PhonePrice<40000000) NOT NULL
)

CREATE TABLE Customer
(
	CustomerID CHAR(5) PRIMARY KEY CHECK(CustomerID LIKE 'CU[0-9][0-9][0-9]') NOT NULL,
	CustomerName VARCHAR(20) CHECK(LEN(CustomerName)>=3) NOT NULL,
	CustomerEmail VARCHAR(30) CHECK(CustomerEmail LIKE '%@bluejack.com' OR CustomerEmail LIKE '%@sunib.edu') NOT NULL,
	CustomerDOB DATE NOT NULL,
	CustomerGender VARCHAR(6) CHECK(CustomerGender LIKE 'Male' OR CustomerGender LIKE 'Female') NOT NULL,
	CustomerPhoneNum VARCHAR(15) NOT NULL,
	CustomerAddress VARCHAR(255) NOT NULL
)

CREATE TABLE SalesTransactionDetail
(
	SalesTransactionDetailID CHAR(5) PRIMARY KEY CHECK(SalesTransactionDetailID LIKE 'SD[0-9][0-9][0-9]') NOT NULL,
	PhoneName VARCHAR(20) NOT NULL,
	PhoneID CHAR(5) FOREIGN KEY REFERENCES Phone(PhoneID) ON UPDATE CASCADE ON DELETE CASCADE NOT NULL,
	PhoneQty INT NOT NULL
)

CREATE TABLE SalesTransaction
(
	SalesTransactionID CHAR(5) PRIMARY KEY CHECK(SalesTransactionID LIKE 'SH[0-9][0-9][0-9]') NOT NULL,
	SalesTransactionDetailID CHAR(5) FOREIGN KEY REFERENCES SalesTransactionDetail(SalesTransactionDetailID) ON UPDATE CASCADE ON DELETE CASCADE NOT NULL,
	StaffID CHAR(5) FOREIGN KEY REFERENCES Staff(StaffID) ON UPDATE CASCADE ON DELETE CASCADE NOT NULL,
	CustomerID CHAR(5) FOREIGN KEY REFERENCES Customer(CustomerID) ON UPDATE CASCADE ON DELETE CASCADE NOT NULL,
	TransactionDate DATE NOT NULL,
)

CREATE TABLE PurchaseTransactionDetail
(
	PurchaseTransactionDetailID CHAR(5) PRIMARY KEY CHECK(PurchaseTransactionDetailID LIKE 'PD[0-9][0-9][0-9]') NOT NULL,
	PhoneName VARCHAR(20) NOT NULL,
	PhoneID CHAR(5) FOREIGN KEY REFERENCES Phone(PhoneID) ON UPDATE CASCADE ON DELETE CASCADE NOT NULL,
	PhoneQty INT NOT NULL
)

CREATE TABLE PurchaseTransaction
(
	PurchaseTransactionID CHAR(5) PRIMARY KEY CHECK(PurchaseTransactionID LIKE 'PH[0-9][0-9][0-9]') NOT NULL,
	PurchaseTransactionDetailID CHAR(5) FOREIGN KEY REFERENCES PurchaseTransactionDetail(PurchaseTransactionDetailID) ON UPDATE CASCADE ON DELETE CASCADE NOT NULL,
	StaffID CHAR(5) FOREIGN KEY REFERENCES Staff(StaffID) ON UPDATE CASCADE ON DELETE CASCADE NOT NULL,
	VendorID CHAR(5) FOREIGN KEY REFERENCES Vendor(VendorID) ON UPDATE CASCADE ON DELETE CASCADE NOT NULL,
	TransactionDate DATE NOT NULL,
)