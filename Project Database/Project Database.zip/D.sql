INSERT INTO PurchaseTransaction VALUES
('PH016','PD016','ST010','VE006','2021-04-15');

INSERT INTO SalesTransaction VALUES
('SH016','SD016','ST004','CU008','2021-06-10');

INSERT INTO PurchaseTransactionDetail VALUES
('PD026','Treant','PO010','2');

INSERT INTO SalesTransactionDetail VALUES
('SD026','Treant','PO010','1');